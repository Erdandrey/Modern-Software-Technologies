## E_PAR_MISSING_KEY

Thrown when a parameter misses a required key.

Error object:

| Attribute | Value |
| --- | --- |
| code | `E_PAR_MISSING_KEY` |
| key | Name of the missing parameter's key |
| name | Name of the missing parameter |
