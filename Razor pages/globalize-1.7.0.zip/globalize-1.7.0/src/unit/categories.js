define(function() {

/**
 * categories()
 *
 * Return all unit categories.
 */
return [ "acceleration", "angle", "area", "digital", "duration", "length", "mass", "power",
"pressure", "speed", "temperature", "volume" ];

});
