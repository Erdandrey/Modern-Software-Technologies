define(function() {

// Based on http://stackoverflow.com/questions/7616461/generate-a-hash-from-string-in-javascript-jquery
return function( str ) {
	return [].reduce.call( str, function( hash, i ) {
		var chr = i.charCodeAt( 0 );
		hash = ( ( hash << 5 ) - hash ) + chr;
		return hash | 0;
	}, 0 );
};

});
